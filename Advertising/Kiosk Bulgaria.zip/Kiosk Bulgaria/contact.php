<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
<head>
<title>Киоск България ООД - информационни киоски за обществен достъп до информация и интернет - Контакти</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta content="kiosk,kiosks,kioski,sale,KIOSKY,bulgaria,model,customers,partners,references,terminal,bulgaria,information,terminals,saw,touchscreen,touch,screen,tft,wall,outdoor,internet kiosk,metal keyboard,trackball,contact us" name="keywords">
<meta content="киоск,киоски,киоскай,инфомационни,клиенти,референции,препоръки,терминал,българия,терминали,акустични вълни,тъчскрийн,уеб,интернет киоск,метална клавиатура,тракбол,електронен,контакти" name="keywords">
<meta name="description" content="Киоск България ООД - Контакт с нас, телефони за връзка, адрес, тлефон, факс, ЕИК, мейл и e-mail на Киоск България ООД">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="cache-control" content="no-cache">
<link rel="shortcut icon" type="image/x-icon" href="http://www.kioskbg.com/images/icon32x32.ico"/>
<link rel="icon" type="image/ico" href="http://www.kioskbg.com/images/icon24x24.ico"/>
<link href="style.css" type="text/css" rel="stylesheet">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<script language="JavaScript">
<!--
function checkMail ( email ) {
 var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/ ;
 if ( filter. test ( email ) ) {
 	return true ;
 }
 return false ;
} 

function check_it()
{
 var complete=true;
 
 var name = document.MAIL_FORM.name.value;
 var mail = document.MAIL_FORM.email.value;
 var message = document.MAIL_FORM.message.value;
 var err = "Не сте попълнили следните полета: \n";
 
 if(name == "") {err += "Име \n"; complete= false;}
 if(mail == "") {err += "E-mail \n"; complete= false;}
 if(message == "") {err += "Съобщение"; complete= false;}
 
 if (complete == false)
 {
	alert(err);
 }
 else  if (!checkMail(mail))
 {
   alert ("Въведеният електронен адрес не е валиден!");
   complete= false;
 }
 return complete;
}
//-->
</script>
</head>
<body onLoad="MM_preloadImages('images/b1bgr.jpg','images/b2bgr.jpg','images/b3bgr.jpg','images/b4bgr.jpg','images/b5bgr.jpg','images/b6bgr.jpg','images/b7bgr.jpg','images/fb_r.png','images/tw_r.png')">
<table width="996" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="821" valign="top"><a href="index.htm"><img src="images/kiosk_bg_logo.png" width="254" height="76" border="0"></a></td>
    <td width="175" height="76" valign="middle"><div align="center">
      <table width="110" height="40" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td valign="middle" class="style6"><div align="right"><a href="contact_en.php">English</a></div></td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td><a href="index.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Home','','images/b1bgr.gif',1)"><img src="images/b1bgn.gif" alt="Начало" name="Home" width="110" height="30" border="0"></a><a href="kiosks.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Kiosks','','images/b2bgr.gif',1)"><img src="images/b2bgn.gif" alt="Киоски" name="Kiosks" width="107" height="30" border="0"></a><a href="applications.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Applications','','images/b3bgr.gif',1)"><img src="images/b3bgn.gif" alt="Приложение" name="Applications" width="138" height="30" border="0"></a><a href="technologies.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Technologies','','images/b4bgr.gif',1)"><img src="images/b4bgn.gif" alt="Технологии" name="Technologies" width="125" height="30" border="0"></a><a href="references.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('References','','images/b5bgr.gif',1)"><img src="images/b5bgn.gif" alt="Референции" name="References" width="136" height="30" border="0"></a><a href="about.htm" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('About','','images/b6bgr.gif',1)"><img src="images/b6bgn.gif" alt="За нас" name="About" width="93" height="30" border="0"></a><a href="contact.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Contact','','images/b7bga.gif',1)"><img src="images/b7bga.gif" alt="Контакти" name="Contact" width="112" height="30" border="0"></a></td>
    <td width="175" rowspan="2" valign="top" background="images/8.gif">
      <table width="140" height="20" border="0" align="right"  cellpadding="0" cellspacing="0">
        <tr>
		<td height="4"></td>
		</tr>
		<tr>
          <td height="25" valign="middle">
			<form id="form_search" name="form_search" method="get" action="http://www.google.com/search" style="display:inline;">
			<input name="q" type="text" class="search" id="top_search" size="8"/>
			<input type="hidden" name="hl" value="" />
			<input type="hidden" name="as_sitesearch" value="www.kioskbg.com" />
			<input name="top_search_btn" type="submit" id="top_search_btn" class="search_bg" value="" /></form> 
		  </td>
        </tr>
    </table></td>
  </tr>
  <tr valign="top">
    <td height="14" colspan="2"><img src="images/shadow25_821.png" width="821" height="14"></td>
  </tr>
  <tr>
    <td height="9" colspan="3"><div align="center"><img src="images/white_body_top.gif" width="996" height="9"></div></td>
  </tr>
  <tr valign="top" bgcolor="#FFFFFF" background="images/white_body.gif">
    <td height="424" colspan="3" background="images/white_body.gif"><div align="center">
	<table width="914" height="68" border="0" cellpadding="0" cellspacing="0">
        <tr align="left" valign="middle">
          <td width="42" height="52"></td>
          <td width="446" class="style4">Контакти</td>
          <td width="426" height="52" class="style4">Бързо запитване</td>
        </tr>
      </table>
	<table width="914" height="434" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="42" height="380" valign="top"><p align="left">&nbsp;</p></td>
          <td width="432" valign="top" class="style1"><strong><br>
            Киоск България ООД<br />
              <br />
          </strong>ЕИК 200204581<br />
          <br />
          <br />
          <strong>Адрес<br />
          <br />
          </strong>България, Шумен 9700, ЖК Южен бряг, Блок 3<br />
          <br />
          <br />
          <strong>Телефони<br />
          <br />
          </strong>+359 54 88 81 18 <br />
          <br />
+359 897 90 66 96<br>
<br>
+359 899 13 13 23<br />
        <br />
        <br />
        <strong>Факс</strong><br />
        <br />
+359 54 80 18 68 <br />
<br />
<br />
<strong>e-mail<br />
<br />
</strong><a href="mailto:office@kioskbg.com">office@kioskbg.com</a></td>
          <td width="380" align="left" valign="top">
                        <br />
            <div class="mailform" align="left">
              <form id="form" action="" method="post" name="MAIL_FORM" onsubmit="return check_it();">
                <span class="NB"> Име<span class="style8">*</span></span><br />
                <input name="name" type="text" onfocus="if (value=='') value=''" onblur="if (value=='') value=''" size="52" />
                <br />
                <span class="NB">Организация</span><br />
                <input name="organisation" type="text" onfocus="if (value=='') value=''" onblur="if (value=='') value=''" size="52" />
                <br />
                <span class="NB">Телефон</span><br />
                <input name="telephone" type="text" onfocus="if (value=='') value=''" onblur="if (value=='') value=''" size="52" />
                <br />
                <span class="NB">E-mail<span class="style8">*</span></span><br />
                <input name="email" type="text" onfocus="if (value=='') value=''" onblur="if (value=='') value=''" value="" size="52" />
                <br />
                <span class="NB">Съобщение<span class="style8">*</span> </span><br />
                <textarea name="message" cols="5" wrap="VIRTUAL" onfocus="if (value=='') value=''" onblur="if (value=='') value=''"></textarea>
                <br />
                <br />
                <center>
                  <input type="submit" name="MAIL_FORM_SUBMIT" value="Изпрати" />
                  <input name="reset" type="reset" value="Изчисти" />
                </center>
              </form>
              <span class="NB"><left></left></span></div>
                      </td>
          <td width="60" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="45" colspan="2" valign="top"></td>
          <td colspan="2" valign="top">Полетата маркирани със <span class="style8">*</span> са необходими, за да получим запитването.</td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="9" colspan="3"><img src="images/white_body_bottom.gif" width="996" height="9"></td>
  </tr>
  <tr valign="top">
    <td height="14" colspan="3"><img src="images/shadow.png" width="996" height="12"></td>
  </tr>
  <tr valign="middle" background="images/bottom.png">
    <td height="200" colspan="3" background="images/bottom.png"><table width="940" height="156" border="0" align="center" cellpadding="0" cellspacing="0" class="style7">
      <tr>
        <td width="10" class="style7"></td>
        <td width="206" valign="top" class="style7"><strong><a href="kiosks.htm">Модели киоски</a></strong></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="34" rowspan="7" valign="top"></td>
        <td width="206" valign="top" class="style7"><strong><a href="applications.htm">Приложения на киоските</a></strong></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="34" rowspan="7" valign="top"></td>
        <td width="206" valign="top" class="style7"><strong><a href="technologies.htm">Технологии</a></strong></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="35" rowspan="7" valign="top"></td>
        <td width="206" valign="top" class="style7"><strong><a href="contact.php">Контакти</a></strong></td>
      </tr>
      <tr>
        <td width="10" height="10" class="style7">&nbsp;</td>
        <td width="206" valign="top" class="style7">&nbsp;</td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"></td>
      </tr>
      <tr>
        <td width="10" class="style7">&nbsp;</td>
        <td width="206" valign="top" class="style7"><a href="kiosks_mx_series_bg.htm">Киоски MX серия</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="malls.htm">Търговски центрове</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="touchscreen.htm">Тъч монитори</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7">Киоск България ООД </td>
      </tr>
      <tr>
        <td width="10" class="style7">&nbsp;</td>
        <td width="206" valign="top" class="style7"><a href="kiosks_fx_series_bg.htm">Киоски FX серия</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="banks.htm">Банки</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="software.htm">Софтуер</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7">Шумен 9700, България </td>
      </tr>
      <tr>
        <td width="10" class="style7">&nbsp;</td>
        <td width="206" valign="top" class="style7"><a href="kiosks_cr_series_bg.htm">Киоски CR серия</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="government.htm">Държавна администрация</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="metalkeyboard.htm">Метални клавиатури</a> </td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7">ЖК Южен бряг 3, Бл.3 </td>
      </tr>
      <tr>
        <td width="10" class="style7">&nbsp;</td>
        <td width="206" valign="top" class="style7"><a href="kiosks_ds_series_bg.htm">Киоски DS серия</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="education.htm">Образование</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="printers.htm">Принтери</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7">+359 54 888 118 </td>
      </tr>
      <tr>
        <td width="10" class="style7">&nbsp;</td>
        <td width="206" valign="top" class="style7"><a href="kiosks.htm">още...</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="applications.htm">още...</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="technologies.htm">още...</a></td>
        <td width="1" valign="top" bgcolor="#999999"></td>
        <td width="206" valign="top" class="style7"><a href="mailto:office@kioskbg.com">office@kioskbg.com</a></td>
      </tr>
    </table></td>
  </tr>
  <tr valign="top">
    <td height="12" colspan="3"><img src="images/shadow.png" width="996" height="12"></td>
  </tr>
</table>
<table width="944" height="35" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="114" height="20" valign="middle"><div align="left"><span class="style6">Намерете ни и във</span></div></td>
    <td width="430" height="20" valign="middle"><div align="left"><a href="http://www.facebook.com/KioskBulgaria" target="_blank" title="Намерете Киоск България и във Facebook" onMouseOver="MM_swapImage('SML1','','images/fb_r.png',1)" onMouseOut="MM_swapImgRestore()"><img src="images/fb_n.png" alt="Facebook" name="SML1" width="20" height="20" border="0" id="SML1" /></a>&nbsp;<a href="https://twitter.com/#!/KioskBulgaria" target="_blank" title="Намерете ни в Twitter" onMouseOver="MM_swapImage('SML2','','images/tw_r.png',1)" onMouseOut="MM_swapImgRestore()"><img src="images/tw_n.png" alt="Twitter" name="SML2" width="20" height="20" border="0" id="SML2" /></a> </div>
        <div align="right"></div></td>
    <td width="400" valign="middle"><div align="right" class="style6">2008 - 2017 Киоск България ООД </div></td>
  </tr>
  <tr>
    <td width="114" height="12" valign="middle"></td>
    <td height="12" colspan="2"></td>
  </tr>
</table>
</body>
</html>