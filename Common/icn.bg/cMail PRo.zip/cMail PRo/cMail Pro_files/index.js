var Sliders = [];
window.addEvent("domready", function () {
    $$("p.slider select").each(function (select, sID) {
	select.setStyle("display","none");
	var options = select.getElements("option");

	// create slider elements
	var slider = new Element("span",{"class":"slider"});
	slider.inject(select, "after");
	var knob = new Element("span", {"class":"knob"});
	knob.inject(slider);
	// knob.setStyle("margin-left",50/options.length + "%");
	var overlay = new Element("span", {"class":"overlay"});
	overlay.inject(slider);

	var labelset = new Element("span", {"class":"labelset"});
	labelset.inject(slider, "after");
	labelset.setStyles({
	    "width": (100 + 100/(options.length - 1)) + "%",
	    "left": (-50/(options.length - 1)) + "%"
	});


	if (options.length == 2) {
	    overlay.setStyle("width", "50%");
	};

	// Activate slider
	Sliders[sID] = new Slider(slider, knob, {
	    range: [0, options.length - 1],
            snap: true,
	    offset: 10,
            steps: options.length - 1,
	    initialStep: 0,
	    onChange: function(value){
		options.each(function (option) {
		    option.selected = false;
		});
		options[value].selected = true;
		if (options.length == 2) {
		    overlay.setStyle("left", (50*value/(options.length-1)) + "%");
		} else {
		    overlay.setStyle("right", (100 - 100*value/(options.length-1)) + "%");
		}
	    }
	});
	// Add Labels to steps
	options.each(function (option, oID) {
	    var label = new Element("span", {"class":"label"});
	    new Element("span").set("text",option.get("text")).inject(label);
	    label.setStyle("width", 100/(options.length) + "%");
	    label.inject(labelset);
	    if (oID == 0 || oID == options.length - 1) {
		label.addClass("noline");
	    }
	    label.addEvent("click", function () {
		Sliders[sID].set(oID);
	    });
	});

    });
});

window.addEvent("resize", function () {
    Sliders.each(function (slider) {
	slider.autosize();
    });
});

(function() {
  try {
    document.createEvent("TouchEvent");
  } catch(e) {
    return;
  }

  ['touchstart', 'touchmove', 'touchend'].each(function(type){
      Element.NativeEvents[type] = 2;
  });

  var mapping = {
    'mousedown': 'touchstart',
    'mousemove': 'touchmove',
    'mouseup': 'touchend'
  };

  var condition = function(event) {
    var touch = event.event.changedTouches[0];
    event.page = {
      x: touch.pageX,
      y: touch.pageY
    };
    return true;
  };

  for (var e in mapping) {
    Element.Events[e] = {
      base: mapping[e],
      condition: condition
    };
  }
})();