var WinScroll;
window.addEvent("domready", function () {
    if (Browser.Platform.ios) {
	$$("div").addEvent("click", function () {});
    };
    var nav = $("main-nav");
    if ($(window.document).getSize().x > 1000) {
	$(window.document).addEvent("scroll", function () {
	    if (this.getScroll().y > 40) {
		if (! nav.hasClass("main-nav-fixed")) nav.addClass("main-nav-fixed");
	    } else {
		if (nav.hasClass("main-nav-fixed")) nav.removeClass("main-nav-fixed");
	    }
	});
    }
    WinScroll = new Fx.SmoothScroll({ offset: { x: 0, y: -100 }});
});

