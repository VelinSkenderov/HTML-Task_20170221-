{\rtf1\ansi\ansicpg1252\cocoartf1265\cocoasubrtf210
{\fonttbl\f0\fmodern\fcharset0 CourierNewPSMT;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\ri720\sb120\sa120

\f0\fs18 \cf0 <?php\
//set database connection info for database to import\
$hostname\'a0=\'a0\uc0\u8243 localhost\u8243 ;\
$username\'a0=\'a0\uc0\u8243 USERNAME\u8243 ;\
$password\'a0=\'a0\uc0\u8243 PASSWORD\u8243 ;\
$sourcedb\'a0=\'a0\uc0\u8243 DATABASE\u8243 ; // database to import from\
$sourcetable\'a0=\'a0\uc0\u8243 stories\u8243 ; // table that stores posts to import\
$sourcecomments\'a0=\'a0\uc0\u8243 comment\u8243 ; // table that stores comments to import\
\
//set database connection info for WordPress database\
$destdb\'a0=\'a0\uc0\u8243 WORDPRESS-DATABASE\u8243 ; // WordPress database\
$wp_prefix\'a0=\'a0\uc0\u8243 wp_\u8243 ; // WordPress table prefix\
\
//database connection\
$db_connect\'a0=\'a0@mysql_connect($hostname, $username, $password)\
  or die(\uc0\u8243 Fatal Error: \u8243 .mysql_error());\
\
mysql_select_db($sourcedb, $db_connect);\
\
$srcresult\'a0=\'a0mysql_query(\uc0\u8243 select * from $sourcetable\u8243 , $db_connect)\
  or die(\uc0\u8243 Fatal Error: \u8243 .mysql_error());\
\
// used to generate the dashed titles in the URLs\
function sanitize($title) \{\
  $title\'a0=\'a0strtolower($title);\
  $title\'a0=\'a0preg_replace(\'91/&.+?;/\'92, \'91\'92, $title); // kill entities\
  $title\'a0=\'a0preg_replace(\'91/[^a-z0-9 _-]/\'92, \'91\'92, $title);\
  $title\'a0=\'a0preg_replace(\'91/\\s+/\'92, \'91 \'92, $title);\
  $title\'a0=\'a0str_replace(\'91 \'92, \'91-\'92, $title);\
  $title\'a0=\'a0preg_replace(\'91|-+|\'92, \'91-\'92, $title);\
  $title\'a0=\'a0trim($title, \'91-\'92);\
\
  return $title;\
\}\
\
while ($myrow\'a0=\'a0mysql_fetch_array($srcresult))\
\{\
\
  //generate post title\
  $my_title\'a0=\'a0mysql_escape_string($myrow['title']);\
\
  //generate post content\
  $my_content\'a0=\'a0mysql_escape_string($myrow['content']);\
\
  //generate post permalink\
  $myname\'a0=\'a0mysql_escape_string(sanitize($my_title));\
  //generate SQL to insert data into WordPress\
  $sql\'a0=\'a0\uc0\u8243 INSERT INTO \'91\u8243  . $wp_prefix . \u8243 posts\'92\
(\
\
    \'91ID\'92 ,\
\
    \'91post_author\'92 ,\
    \'91post_date\'92 ,\
    \'91post_date_gmt\'92 ,\
    \'91post_content\'92 ,\
    \'91post_title\'92 ,\
    \'91post_name\'92 ,\
    \'91post_category\'92 ,\
    \'91post_excerpt\'92 ,\
    \'91post_status\'92 ,\
    \'91comment_status\'92 ,\
    \'91ping_status\'92 ,\
    \'91post_password\'92 ,\
    \'91to_ping\'92 ,\
    \'91pinged\'92 ,\
    \'91post_modified\'92 ,\
    \'91post_modified_gmt\'92 ,\
    \'91post_content_filtered\'92 ,\
    \'91post_parent\'92,\
    \'91post_type\'92 )\
    VALUES\
\
(\
    \'91$myrow[sid]\'92,\
        \'911\'92,\
    \'91$myrow[time]\'92,\
    \'910000-00-00 00:00:00\'92,\
    \'91$my_content\'92,\
    \'91$my_title\'92,\
    \'91$myname\'92,\
    \'91$myrow[category]\'92,\
    \'91\'92,\
    \'91publish\'92,\
    \'91open\'92,\
    \'91open\'92,\
    \'91\'92,\
    \'91\'92,\
    \'91\'92,\
    \'91$myrow[time]\'92,\
    \'910000-00-00 00:00:00\'92,\
    \'91\'92,\
    \'910\'92,\
    \'91post\'92 );\uc0\u8243 ;\
\
    mysql_select_db($destdb, $db_connect);\
    //execute query\
    mysql_query($sql, $db_connect);\
\
    // load the ID of the post we just inserted\
    $sql\'a0=\'a0\uc0\u8243 select MAX(ID) from \u8243  . $wp_prefix . \u8243 posts\u8243 ;\
    $getID\'a0=\'a0mysql_query($sql, $db_connect);\
    $currentID\'a0=\'a0mysql_fetch_array($getID);\
    $currentID\'a0=\'a0$currentID['MAX(ID)'];\
\
    // retrieve all associated post comments\
    $mysid\'a0=\'a0$myrow[\uc0\u8243 pn_sid\u8243 ];\
    mysql_select_db($sourcedb, $db_connect);\
    $comments\'a0=\'a0mysql_query(\uc0\u8243 select * from \u8243 \
        .$sourcecomments. \uc0\u8243  where pn_sid\'a0=\'a0$mysid\u8243 , $db_connect);\
    //import post comments in WordPress\
    while ($comrow\'a0=\'a0mysql_fetch_array($comments))\
    \{\
\
      $myname\'a0=\'a0mysql_escape_string($comrow['pn_name']);\
      $myemail\'a0=\'a0mysql_escape_string($comrow['pn_email']);\
      $myurl\'a0=\'a0mysql_escape_string($comrow['pn_url']);\
      $myIP\'a0=\'a0mysql_escape_string($comrow['pn_host_name']);\
      $mycomment\'a0=\'a0mysql_escape_string($comrow['pn_comment']);\
      $sql\'a0=\'a0\uc0\u8243 INSERT INTO \'91\u8243  . $wp_prefix . \u8243 comments\'92\
      (\
        \'91comment_ID\'92 ,\
        \'91comment_post_ID\'92 ,\
        \'91comment_author\'92 ,\
        \'91comment_author_url\'92 ,\
\
        \'91comment_author_IP\'92 ,\
        \'91comment_date\'92 ,\
        \'91comment_date_gmt\'92 ,\
        \'91comment_content\'92 ,\
        \'91comment_karma\'92 ,\
        \'91comment_approved\'92 ,\
        \'91user_id\'92 )\
        VALUES\
        (\
          \'91\'92,\
          \'91$currentID\'92,\
          \'91$myname\'92,\
          \'91$myemail\'92,\
          \'91$myurl\'92,\
          \'91$myIP\'92,\
          \'91$comrow[date]\'92,\
          \'910000-00-00 00:00:00\'92,\
          \'91$mycomment\'92,\
          \'910\'92,\
          \'911\'92,\
          \'910\'92\
        );\uc0\u8243 ;\
      if ($submit)\
      \{\
        mysql_select_db($destdb, $db_connect);\
        mysql_query($sql, $db_connect)\
          or die(\uc0\u8243 Fatal Error: \u8243 .mysql_error());\
      \}\
    \}\
\
\
  \}\
\
  //Update comment count\
  mysql_select_db($destdb, $db_connect);\
  $tidyresult\'a0=\'a0mysql_query(\uc0\u8243 select * from $wp_prefix\u8243  . \u8243 posts\u8243 , $db_connect)\
    or die(\uc0\u8243 Fatal Error: \u8243 .mysql_error());\
\
  while ($myrow\'a0=\'a0mysql_fetch_array($tidyresult))\
  \{\
    $mypostid=$myrow['ID'];\
    $countsql=\uc0\u8243 select COUNT(*) from $wp_prefix\u8243  . \u8243 comments\u8243 \
       . \uc0\u8243  WHERE \'91comment_post_ID\'92\'a0=\'a0\u8243  . $mypostid;\
    $countresult=mysql_query($countsql) or die(\uc0\u8243 Fatal Error: \u8243 .mysql_error());\
    $commentcount=mysql_result($countresult,0,0);\
    $countsql=\uc0\u8243 UPDATE \'91\u8243  . $wp_prefix . \u8243 posts\'92\
      SET \'91comment_count\'92\'a0=\'a0\'91\uc0\u8243  . $commentcount .\
      \uc0\u8243 \'91 WHERE \'91ID\'92\'a0=\'a0\u8243  . $mypostid . \u8243  LIMIT 1\u8243 ;\
\
\
    $countresult=mysql_query($countsql) or die(\uc0\u8243 Fatal Error: \u8243 .mysql_error());\
\
  \}}